const SyncLogger = (() => {
  // Diagnostic persistence is intentionally opt-in because frequent writes to
  // chrome.storage can slow down large sync runs.
  const enabled = globalThis.__PRODUCT_SYNC_LOGGING_ENABLED__ === true;

  function isEnabled() {
    return enabled;
  }

  async function log(entry) {
    if (!enabled) {
      return {
        timestamp: new Date().toISOString(),
        ...entry
      };
    }

    const normalized = {
      timestamp: new Date().toISOString(),
      ...entry
    };
    try {
      await ExtensionStorage.appendLog(normalized);
    } catch (error) {
      console.error("[ProductSync] Could not persist diagnostic log", error);
    }
    return normalized;
  }

  return {
    isEnabled,
    log
  };
})();
