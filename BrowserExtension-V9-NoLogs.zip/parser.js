const AmazonProductParser = (() => {
  function parse(payload) {
    const listing = payload?.reconciledListing?.detailPageListingResponse || {};

    return {
      asin: stringOrEmpty(payload?.asin),
      title: nestedValue(listing["item_name#1.value"]),
      brand: nestedValue(listing["brand#1.value"]),
      mpn: nestedValue(listing["part_number#1.value"]),
      imageUrl: stringOrEmpty(payload?.imageUrl) || nestedValue(listing.detail_page_primary_image_url)
    };
  }

  function nestedValue(node) {
    return stringOrEmpty(node?.value);
  }

  function stringOrEmpty(value) {
    return typeof value === "string" ? value : "";
  }

  return {
    parse
  };
})();
